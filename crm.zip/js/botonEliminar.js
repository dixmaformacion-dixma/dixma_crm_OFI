    
    function eliminarUsuario(idUsuario) {

        window.location.href = "eliminarUsuario.php?idUsuario=" + idUsuario;


    }

    function eliminarEmpresa(idEmpresa){

        window.location.href = "eliminarEmpresa.php?idEmpresa=" + idEmpresa;

    }