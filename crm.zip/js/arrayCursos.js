
$(document).ready(function() {

    $("#selectTipoCurso").change(function() {

        var tipoCurso = $("#selectTipoCurso").val();

        $.ajax({
            type: "GET",
            url: "json/cursos.json",
            data: "",
            dataType: "json",
            success: function (cursos) {
                
                $("#selectCurso").empty();

                for(i=0; i < cursos.length; i++) {

                    if(tipoCurso == cursos[i]['tipoCurso']){

                        $("#selectCurso").append("<option>" + cursos[i]['nombreCurso'] + "</option>");

                    }

                }

            }, error: function() {
                console.log('error');
            }
        });

    })


});

