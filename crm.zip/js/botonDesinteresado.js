
function desinteresado(idempresa, codigoCurso) {

    window.location.href = "eliminarCurso.php?idEmpresa=" + idempresa + "&codigoCurso=" + codigoCurso;


}

function noEliminar() {

    window.location.href = "cursosInteresados.php";

}


