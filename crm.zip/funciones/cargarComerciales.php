<?php

    function cargarComerciales(){

            $comerciales = [];

            $conexionPDO = realizarConexion();
            $sql = "SELECT nombre, codigousuario, activo FROM usuarios";
            $stmt = $conexionPDO->query($sql);

            while($comercial = $stmt->fetch()){

                array_push($comerciales, $comercial);

            }

            unset($conexionPDO);

            return $comerciales;

    }

    function nombreComercial($codigoUsuario){

        $conexionPDO = realizarConexion();
        $sql = "SELECT nombre FROM usuarios WHERE codigousuario = $codigoUsuario ";
        $stmt = $conexionPDO->query($sql);

        while($comercial = $stmt->fetch()){

            return $comercial;

        }

        unset($conexionPDO);

    }

?>